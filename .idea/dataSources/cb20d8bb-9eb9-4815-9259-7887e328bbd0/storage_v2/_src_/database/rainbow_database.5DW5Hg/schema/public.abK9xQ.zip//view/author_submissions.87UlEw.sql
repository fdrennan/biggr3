create view author_submissions(author, title, n_obs) as
SELECT submissions.author,
       submissions.title,
       count(*) AS n_obs
FROM submissions
GROUP BY submissions.author, submissions.title
ORDER BY (count(*)) DESC;

alter table author_submissions
    owner to unicorn_user;

