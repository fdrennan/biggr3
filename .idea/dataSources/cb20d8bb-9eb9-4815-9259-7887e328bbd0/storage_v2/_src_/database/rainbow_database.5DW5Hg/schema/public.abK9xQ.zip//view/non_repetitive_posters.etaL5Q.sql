create view non_repetitive_posters(diff_time, author, title, subreddit, permalink, selftext) as
SELECT now() - s.time_collected_utc AS diff_time,
       s.author,
       s.title,
       s.subreddit,
       s.permalink,
       s.selftext
FROM submissions s
         LEFT JOIN replicated_titles rt ON s.author::text = rt.author::text
WHERE rt.remove IS NULL
ORDER BY s.time_collected_utc DESC;

alter table non_repetitive_posters
    owner to unicorn_user;

