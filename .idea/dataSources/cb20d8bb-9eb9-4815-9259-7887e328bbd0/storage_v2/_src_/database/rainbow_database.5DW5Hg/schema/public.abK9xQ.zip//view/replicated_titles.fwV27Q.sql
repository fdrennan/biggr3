create view replicated_titles(author, title, remove) as
SELECT author_submissions.author,
       author_submissions.title,
       true AS remove
FROM author_submissions
WHERE author_submissions.n_obs > 1;

alter table replicated_titles
    owner to unicorn_user;

