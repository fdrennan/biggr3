create view submissions_local(diff_time, title, subreddit, selftext) as
SELECT now() - submissions.time_collected_utc AS diff_time,
       submissions.title,
       submissions.subreddit,
       submissions.selftext
FROM submissions
WHERE submissions.selftext::text ~~* '%colorado%'::text
   OR submissions.title::text ~~* '%colorado%'::text
   OR submissions.title::text ~~* '%fort collins%'::text
   OR submissions.selftext::text ~~* '%fort collins%'::text
ORDER BY submissions.time_collected_utc DESC;

alter table submissions_local
    owner to unicorn_user;

